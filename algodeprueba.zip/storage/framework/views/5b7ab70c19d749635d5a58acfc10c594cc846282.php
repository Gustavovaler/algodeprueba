<?php $__env->startSection('content'); ?>
    


            <div class="content">
               
                <h1>Hagamos algo importante !!</h1>
            </div>
        </div>
    </body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\algodeprueba\algodeprueba\resources\views/welcome.blade.php ENDPATH**/ ?>