@extends('layouts.app')

@section('content')
    
{{-- 
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Inicio</a>
                    @else
                        <a href="{{ route('login') }}">Loguear</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}">Registrarse</a>
                        @endif
                    @endauth
                </div>
            @endif --}}

            <div class="content">
               
                <h1>Hagamos algo importante !!</h1>
            </div>
        </div>
    </body>
</html>

@endsection